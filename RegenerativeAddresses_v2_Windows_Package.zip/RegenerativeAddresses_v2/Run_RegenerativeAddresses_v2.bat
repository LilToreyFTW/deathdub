@echo off
cd /d "%~dp0"
echo Starting Regenerative Addresses Tool v2.0...
echo.
echo =-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
echo   Regenerative Addresses Tool v2.0
echo   Educational Security Testing Tool
echo =-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
echo.
python regenerative-addresses-new.py
if errorlevel 1 (
    echo.
    echo Error running v2.0, trying original version...
    python regenerative-addresses.py
)
pause
