# Regenerative Addresses Tool v2.0 - Windows Package

## NEW FEATURES v2.0:
- Completely rebuilt interface with modern GUI
- Enhanced PHP web interface integration
- Improved proxy management
- Better session handling
- Educational Kali tools integration
- HTML processing capabilities
- Auto-update functionality

## Installation:
1. Install Python 3.9+ from https://python.org
2. Extract this package to a folder
3. Run "Run_RegenerativeAddresses_v2.bat"

## Alternative Launch Options:
- Run "Start_PHP_Interface.bat" for web interface
- Run directly: python regenerative-addresses-new.py
- Use original version: python regenerative-addresses.py

## Default Login:
Username: admin
Password: admin

## Features:
- Link regeneration with 7 techniques
- 18,835+ proxy addresses  
- Kali Linux tools integration
- PHP web interface
- HTML processing and analysis
- Educational security testing
- Session management
- Auto-updater

## PHP Web Interface:
1. Run "Start_PHP_Interface.bat"
2. Open http://localhost:8000 in browser
3. Login with admin/admin

## Educational Purpose Only:
This tool is designed for legitimate security testing and educational purposes only.
