@echo off
cd /d "%~dp0"
echo Starting PHP Web Interface...
echo.
echo =-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
echo   Regenerative Addresses Tool - PHP Interface
echo   Educational Security Testing Tool
echo =-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
echo.
echo Starting local PHP server...
echo Access: http://localhost:8000
echo Press Ctrl+C to stop server
echo.
cd src
python -m http.server 8000
pause
