# Regenerative Addresses - Windows Package

## Installation:
1. Install Python 3.9+ from https://python.org
2. Run "Run_RegenerativeAddresses.bat"

## Or run directly:
python regenerative-addresses.py

## Login:
Username: admin
Password: admin

## Features:
- Link regeneration
- 18,835+ proxy addresses  
- Kali tools integration
- Credential generation
- Force re-login
