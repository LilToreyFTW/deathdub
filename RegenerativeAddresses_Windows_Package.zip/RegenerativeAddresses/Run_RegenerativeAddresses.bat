@echo off
cd /d "%~dp0"
python regenerative-addresses.py
pause
