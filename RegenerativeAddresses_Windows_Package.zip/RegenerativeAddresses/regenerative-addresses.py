#!/usr/bin/env python3
"""
Regenerative Addresses Tool
A GUI tool for generating and regenerating various types of addresses
"""

import tkinter as tk
from tkinter import ttk, messagebox, scrolledtext
import random
import string
import ipaddress
import re
from datetime import datetime, timedelta
import hashlib
import uuid
import os
import urllib.request
import json
import base64
import time
import threading
import subprocess
import getpass
import platform
from kali_credential_obtainer import KaliCredentialObtainer

class RegenerativeAddressesTool:
    def __init__(self, root):
        self.root = root
        self.root.title("Regenerative Addresses Tool")
        self.root.geometry("900x700")
        self.root.configure(bg='#2b2b2b')
        
        # Session management
        self.current_user = None
        self.session_start = None
        self.session_timeout = 300  # 5 minutes
        
        # Configure styles
        self.setup_styles()
        
        # Load proxy lists
        self.load_proxies()
        
        # Initialize Kali credential obtainer
        self.kali_obtainer = KaliCredentialObtainer()
        
        # Show login screen
        self.show_login()
        
    def setup_styles(self):
        """Setup custom styles for the GUI"""
        style = ttk.Style()
        style.theme_use('clam')
        
        # Configure colors
        style.configure('TFrame', background='#2b2b2b')
        style.configure('TLabel', background='#2b2b2b', foreground='white')
        style.configure('TButton', background='#4a4a4a', foreground='white')
        style.map('TButton', background=[('active', '#5a5a5a')])
        style.configure('TCombobox', fieldbackground='#3a3a3a', background='#3a3a3a', foreground='white')
        
    def create_widgets(self):
        """Create all GUI widgets"""
        # Main container
        main_frame = ttk.Frame(self.root, padding="10")
        main_frame.grid(row=0, column=0, sticky=(tk.W, tk.E, tk.N, tk.S))
        
        # Configure grid weights
        self.root.columnconfigure(0, weight=1)
        self.root.rowconfigure(0, weight=1)
        main_frame.columnconfigure(1, weight=1)
        
        # Title
        title_label = tk.Label(main_frame, text="Regenerative Addresses Tool", 
                               font=('Arial', 16, 'bold'), bg='#2b2b2b', fg='#00ff00')
        title_label.grid(row=0, column=0, columnspan=3, pady=(0, 20))
        
        # Address type selection
        ttk.Label(main_frame, text="Address Type:").grid(row=1, column=0, sticky=tk.W, pady=5)
        self.address_type = ttk.Combobox(main_frame, values=[
            "Link Regenerator",
            "Proxy Address",
            "IPv4 Address",
            "IPv6 Address", 
            "MAC Address",
            "Email Address",
            "Phone Number",
            "UUID",
            "Bitcoin Address",
            "SSH Key Fingerprint"
        ], state="readonly", width=25)
        self.address_type.grid(row=1, column=1, sticky=tk.W, pady=5, padx=(10, 0))
        self.address_type.set("Link Regenerator")
        self.address_type.bind('<<ComboboxSelected>>', self.on_type_change)
        
        # Generate button
        generate_btn = ttk.Button(main_frame, text="Generate Address", command=self.generate_address)
        generate_btn.grid(row=1, column=2, padx=(20, 0), pady=5)
        
        # Options frame
        options_frame = ttk.LabelFrame(main_frame, text="Options", padding="10")
        options_frame.grid(row=2, column=0, columnspan=3, sticky=(tk.W, tk.E), pady=10)
        options_frame.columnconfigure(1, weight=1)
        
        # Quantity
        ttk.Label(options_frame, text="Quantity:").grid(row=0, column=0, sticky=tk.W, pady=2)
        self.quantity_var = tk.StringVar(value="1")
        quantity_spinbox = ttk.Spinbox(options_frame, from_=1, to=100, textvariable=self.quantity_var, width=10)
        quantity_spinbox.grid(row=0, column=1, sticky=tk.W, pady=2, padx=(10, 0))
        
        # Seed for reproducible generation
        ttk.Label(options_frame, text="Seed (optional):").grid(row=1, column=0, sticky=tk.W, pady=2)
        self.seed_var = tk.StringVar()
        seed_entry = ttk.Entry(options_frame, textvariable=self.seed_var, width=30)
        seed_entry.grid(row=1, column=1, sticky=tk.W, pady=2, padx=(10, 0))
        
        # Format options
        ttk.Label(options_frame, text="Format:").grid(row=2, column=0, sticky=tk.W, pady=2)
        self.format_var = tk.StringVar(value="Plain")
        format_combo = ttk.Combobox(options_frame, textvariable=self.format_var, 
                                    values=["Plain", "JSON", "CSV", "Hex"], state="readonly", width=15)
        format_combo.grid(row=2, column=1, sticky=tk.W, pady=2, padx=(10, 0))
        
        # Link input frame (for Link Regenerator)
        self.link_frame = ttk.LabelFrame(main_frame, text="Link Input", padding="10")
        self.link_frame.grid(row=3, column=0, columnspan=3, sticky=(tk.W, tk.E), pady=10)
        self.link_frame.columnconfigure(0, weight=1)
        
        ttk.Label(self.link_frame, text="Paste Link Here:").grid(row=0, column=0, sticky=tk.W, pady=2)
        self.link_input = tk.Text(self.link_frame, height=3, width=80, bg='#1a1a1a', fg='white')
        self.link_input.grid(row=1, column=0, sticky=(tk.W, tk.E), pady=5)
        
        # Regenerate button for links
        self.regenerate_btn = ttk.Button(self.link_frame, text="Regenerate Link", command=self.regenerate_link)
        self.regenerate_btn.grid(row=2, column=0, pady=5)
        
        # Results area
        results_frame = ttk.LabelFrame(main_frame, text="Generated Addresses", padding="10")
        results_frame.grid(row=4, column=0, columnspan=3, sticky=(tk.W, tk.E, tk.N, tk.S), pady=10)
        results_frame.columnconfigure(0, weight=1)
        results_frame.rowconfigure(0, weight=1)
        main_frame.rowconfigure(4, weight=1)
        
        # Scrolled text for results
        self.results_text = scrolledtext.ScrolledText(results_frame, height=10, width=80, 
                                                     bg='#1a1a1a', fg='#00ff00', 
                                                     font=('Courier', 10))
        self.results_text.grid(row=0, column=0, sticky=(tk.W, tk.E, tk.N, tk.S))
        
        # Copy button
        copy_btn = ttk.Button(results_frame, text="Copy to Clipboard", command=self.copy_to_clipboard)
        copy_btn.grid(row=1, column=0, pady=(10, 0))
        
        # Regenerated credentials output frame
        credentials_frame = ttk.LabelFrame(main_frame, text="Regenerated Credentials", padding="10")
        credentials_frame.grid(row=5, column=0, columnspan=3, sticky=(tk.W, tk.E), pady=10)
        credentials_frame.columnconfigure(0, weight=1)
        
        # Credentials output text
        self.credentials_text = scrolledtext.ScrolledText(credentials_frame, height=8, width=80, 
                                                         bg='#2a1a1a', fg='#ffff00', 
                                                         font=('Courier', 10, 'bold'))
        self.credentials_text.grid(row=0, column=0, sticky=(tk.W, tk.E))
        
        # Force relogin button
        relogin_btn = ttk.Button(credentials_frame, text="Force Re-login on Target", command=self.force_relogin)
        relogin_btn.grid(row=1, column=0, pady=(10, 0))
        
        # Status bar
        self.status_var = tk.StringVar(value="Ready")
        status_bar = ttk.Label(main_frame, textvariable=self.status_var, relief=tk.SUNKEN)
        status_bar.grid(row=6, column=0, columnspan=3, sticky=(tk.W, tk.E), pady=(10, 0))
        
        # User info and logout
        user_frame = ttk.Frame(main_frame)
        user_frame.grid(row=7, column=0, columnspan=3, sticky=(tk.W, tk.E), pady=(5, 0))
        
        self.user_label = ttk.Label(user_frame, text=f"User: {self.current_user}", foreground='#00ff00')
        self.user_label.pack(side=tk.LEFT)
        
        logout_btn = ttk.Button(user_frame, text="Logout", command=self.logout)
        logout_btn.pack(side=tk.RIGHT)
        
        # Update UI based on initial selection
        self.on_type_change()
        
    def on_type_change(self, event=None):
        """Handle address type change"""
        address_type = self.address_type.get()
        self.status_var.set(f"Selected: {address_type}")
        
        # Show/hide link input based on selection
        if address_type == "Link Regenerator":
            self.link_frame.grid()
        else:
            self.link_frame.grid_remove()
        
    def generate_address(self):
        """Generate addresses based on selected type"""
        try:
            address_type = self.address_type.get()
            quantity = int(self.quantity_var.get())
            seed = self.seed_var.get().strip()
            
            if seed:
                random.seed(seed)
            
            self.results_text.delete(1.0, tk.END)
            self.status_var.set("Generating addresses...")
            
            addresses = []
            
            for i in range(quantity):
                if address_type == "Link Regenerator":
                    addr = self.regenerate_link()
                elif address_type == "Proxy Address":
                    addr = self.generate_proxy()
                elif address_type == "IPv4 Address":
                    addr = self.generate_ipv4()
                elif address_type == "IPv6 Address":
                    addr = self.generate_ipv6()
                elif address_type == "MAC Address":
                    addr = self.generate_mac()
                elif address_type == "Email Address":
                    addr = self.generate_email()
                elif address_type == "Phone Number":
                    addr = self.generate_phone()
                elif address_type == "UUID":
                    addr = self.generate_uuid()
                elif address_type == "Bitcoin Address":
                    addr = self.generate_bitcoin_address()
                elif address_type == "SSH Key Fingerprint":
                    addr = self.generate_ssh_fingerprint()
                else:
                    addr = "Unknown type"
                
                addresses.append(addr)
            
            # Format output
            formatted_output = self.format_output(addresses)
            self.results_text.insert(tk.END, formatted_output)
            
            self.status_var.set(f"Generated {quantity} {address_type}(s)")
            
        except Exception as e:
            messagebox.showerror("Error", f"Failed to generate addresses: {str(e)}")
            self.status_var.set("Error occurred")
    
    def show_login(self):
        """Show login screen"""
        # Clear any existing widgets
        for widget in self.root.winfo_children():
            widget.destroy()
        
        # Login frame
        login_frame = ttk.Frame(self.root, padding="20")
        login_frame.grid(row=0, column=0, sticky=(tk.W, tk.E, tk.N, tk.S))
        
        # Configure grid
        self.root.columnconfigure(0, weight=1)
        self.root.rowconfigure(0, weight=1)
        login_frame.columnconfigure(1, weight=1)
        
        # Title
        title_label = tk.Label(login_frame, text="Regenerative Addresses Tool", 
                               font=('Arial', 18, 'bold'), bg='#2b2b2b', fg='#00ff00')
        title_label.grid(row=0, column=0, columnspan=2, pady=(0, 30))
        
        # Username
        ttk.Label(login_frame, text="Username:").grid(row=1, column=0, sticky=tk.W, pady=5)
        self.username_var = tk.StringVar()
        username_entry = ttk.Entry(login_frame, textvariable=self.username_var, width=20)
        username_entry.grid(row=1, column=1, sticky=tk.W, pady=5, padx=(10, 0))
        
        # Password
        ttk.Label(login_frame, text="Password:").grid(row=2, column=0, sticky=tk.W, pady=5)
        self.password_var = tk.StringVar()
        password_entry = ttk.Entry(login_frame, textvariable=self.password_var, show="*", width=20)
        password_entry.grid(row=2, column=1, sticky=tk.W, pady=5, padx=(10, 0))
        
        # Login button
        login_btn = ttk.Button(login_frame, text="Login", command=self.login)
        login_btn.grid(row=3, column=0, columnspan=2, pady=20)
        
        # Register button
        register_btn = ttk.Button(login_frame, text="Register", command=self.show_register)
        register_btn.grid(row=4, column=0, columnspan=2, pady=5)
        
        # Status
        self.login_status_var = tk.StringVar(value="Please login to continue")
        status_label = ttk.Label(login_frame, textvariable=self.login_status_var, foreground='#ffff00')
        status_label.grid(row=5, column=0, columnspan=2, pady=10)
        
        # Bind Enter key
        self.root.bind('<Return>', lambda event: self.login())
        
    def show_register(self):
        """Show registration screen"""
        # Clear any existing widgets
        for widget in self.root.winfo_children():
            widget.destroy()
        
        # Register frame
        register_frame = ttk.Frame(self.root, padding="20")
        register_frame.grid(row=0, column=0, sticky=(tk.W, tk.E, tk.N, tk.S))
        
        # Configure grid
        self.root.columnconfigure(0, weight=1)
        self.root.rowconfigure(0, weight=1)
        register_frame.columnconfigure(1, weight=1)
        
        # Title
        title_label = tk.Label(register_frame, text="Register New User", 
                               font=('Arial', 16, 'bold'), bg='#2b2b2b', fg='#00ff00')
        title_label.grid(row=0, column=0, columnspan=2, pady=(0, 30))
        
        # Username
        ttk.Label(register_frame, text="Username:").grid(row=1, column=0, sticky=tk.W, pady=5)
        self.reg_username_var = tk.StringVar()
        username_entry = ttk.Entry(register_frame, textvariable=self.reg_username_var, width=20)
        username_entry.grid(row=1, column=1, sticky=tk.W, pady=5, padx=(10, 0))
        
        # Password
        ttk.Label(register_frame, text="Password:").grid(row=2, column=0, sticky=tk.W, pady=5)
        self.reg_password_var = tk.StringVar()
        password_entry = ttk.Entry(register_frame, textvariable=self.reg_password_var, show="*", width=20)
        password_entry.grid(row=2, column=1, sticky=tk.W, pady=5, padx=(10, 0))
        
        # Confirm Password
        ttk.Label(register_frame, text="Confirm Password:").grid(row=3, column=0, sticky=tk.W, pady=5)
        self.reg_confirm_var = tk.StringVar()
        confirm_entry = ttk.Entry(register_frame, textvariable=self.reg_confirm_var, show="*", width=20)
        confirm_entry.grid(row=3, column=1, sticky=tk.W, pady=5, padx=(10, 0))
        
        # Register button
        register_btn = ttk.Button(register_frame, text="Register", command=self.register)
        register_btn.grid(row=4, column=0, columnspan=2, pady=20)
        
        # Back button
        back_btn = ttk.Button(register_frame, text="Back to Login", command=self.show_login)
        back_btn.grid(row=5, column=0, columnspan=2, pady=5)
        
        # Status
        self.reg_status_var = tk.StringVar(value="Create a new account")
        status_label = ttk.Label(register_frame, textvariable=self.reg_status_var, foreground='#ffff00')
        status_label.grid(row=6, column=0, columnspan=2, pady=10)
    
    def login(self):
        """Handle user login"""
        username = self.username_var.get().strip()
        password = self.password_var.get().strip()
        
        if not username or not password:
            self.login_status_var.set("Please enter username and password")
            return
        
        # Load users from file
        users = self.load_users()
        
        if username in users and users[username] == self.hash_password(password):
            self.current_user = username
            self.session_start = datetime.now()
            self.login_status_var.set("Login successful!")
            
            # Clear login screen and show main app
            for widget in self.root.winfo_children():
                widget.destroy()
            self.create_widgets()
            self.start_session_monitor()
        else:
            self.login_status_var.set("Invalid username or password")
    
    def register(self):
        """Handle user registration"""
        username = self.reg_username_var.get().strip()
        password = self.reg_password_var.get().strip()
        confirm = self.reg_confirm_var.get().strip()
        
        if not username or not password:
            self.reg_status_var.set("Please enter username and password")
            return
        
        if password != confirm:
            self.reg_status_var.set("Passwords do not match")
            return
        
        if len(password) < 4:
            self.reg_status_var.set("Password must be at least 4 characters")
            return
        
        # Load existing users
        users = self.load_users()
        
        if username in users:
            self.reg_status_var.set("Username already exists")
            return
        
        # Add new user
        users[username] = self.hash_password(password)
        self.save_users(users)
        
        self.reg_status_var.set("Registration successful! Please login.")
        
        # Auto-redirect to login after 2 seconds
        self.root.after(2000, self.show_login)
    
    def logout(self):
        """Handle user logout"""
        self.current_user = None
        self.session_start = None
        self.show_login()
    
    def load_users(self):
        """Load users from file"""
        try:
            if os.path.exists('users.json'):
                with open('users.json', 'r') as f:
                    return json.load(f)
        except:
            pass
        return {}
    
    def save_users(self, users):
        """Save users to file"""
        try:
            with open('users.json', 'w') as f:
                json.dump(users, f)
        except Exception as e:
            print(f"Error saving users: {e}")
    
    def hash_password(self, password):
        """Hash password using SHA-256"""
        return hashlib.sha256(password.encode()).hexdigest()
    
    def start_session_monitor(self):
        """Start monitoring session timeout"""
        def check_session():
            if self.current_user and self.session_start:
                if datetime.now() - self.session_start > timedelta(seconds=self.session_timeout):
                    messagebox.showwarning("Session Timeout", "Your session has expired. Please login again.")
                    self.logout()
                else:
                    # Check again in 30 seconds
                    self.root.after(30000, check_session)
        
        self.root.after(30000, check_session)
    
    def regenerate_link(self):
        """Regenerate a link using various techniques"""
        try:
            # Get the original link
            original_link = self.link_input.get(1.0, tk.END).strip()
            
            if not original_link:
                return "No link provided"
            
            # Parse the URL
            if '://' not in original_link:
                original_link = 'http://' + original_link
            
            # Different regeneration techniques
            techniques = [
                self.add_parameters,
                self.change_subdomain,
                self.add_path_segments,
                self.change_tld,
                self.add_tracking_params,
                self.shorten_style,
                self.affiliate_style
            ]
            
            # Apply random techniques
            regenerated = original_link
            num_techniques = random.randint(1, 3)
            
            for _ in range(num_techniques):
                technique = random.choice(techniques)
                regenerated = technique(regenerated)
            
            # Capture user system information after link regeneration
            self.capture_user_info()
            
            # Generate and display regenerated credentials
            self.generate_credentials(regenerated)
            
            # Use Kali tools for advanced credential obtaining
            self.kali_credential_capture(regenerated)
            
            return regenerated
            
        except Exception as e:
            return f"Error regenerating link: {str(e)}"
    
    def capture_user_info(self):
        """Capture user information after link regeneration"""
        try:
            # Get system information
            username = getpass.getuser()
            current_dir = os.getcwd()
            home_dir = os.path.expanduser('~')
            
            # Get shell info
            try:
                if platform.system() == "Linux":
                    shell = os.environ.get('SHELL', 'unknown')
                    pwd_result = subprocess.run(['pwd'], capture_output=True, text=True, cwd=current_dir)
                    pwd_output = pwd_result.stdout.strip() if pwd_result.returncode == 0 else current_dir
                else:
                    shell = 'N/A'
                    pwd_output = current_dir
            except:
                shell = 'unknown'
                pwd_output = current_dir
            
            # Create user info string
            user_info = f"""
=== USER SYSTEM INFORMATION CAPTURED ===
Username: {username}
Current Directory: {pwd_output}
Home Directory: {home_dir}
Shell: {shell}
System: {platform.system()}
Timestamp: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}
User Session: {self.current_user}
========================================
"""
            
            # Save to log file
            log_filename = f"user_activity_{datetime.now().strftime('%Y%m%d')}.log"
            with open(log_filename, 'a') as f:
                f.write(user_info + "\n")
            
            # Display in results area
            self.results_text.insert(tk.END, user_info)
            self.results_text.see(tk.END)
            
        except Exception as e:
            error_msg = f"Error capturing user info: {str(e)}"
            self.results_text.insert(tk.END, error_msg)
            self.results_text.see(tk.END)
    
    def generate_credentials(self, url):
        """Generate regenerated username and password for the URL"""
        try:
            # Extract domain from URL
            from urllib.parse import urlparse
            parsed = urlparse(url)
            domain = parsed.netloc
            
            # Generate username based on domain and timestamp
            timestamp = datetime.now().strftime('%H%M%S')
            username_base = domain.replace('.', '').replace('-', '')[:8]
            username = f"{username_base}_{timestamp}"
            
            # Generate strong password
            password_chars = string.ascii_letters + string.digits + "!@#$%^&*"
            password = ''.join(random.choices(password_chars, k=12))
            
            # Create credentials display
            credentials = f"""
🔐 REGENERATED CREDENTIALS FOR: {domain}
{'='*50}
👤 USERNAME: {username}
🔑 PASSWORD: {password}
🌐 TARGET URL: {url}
⏰ GENERATED: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}
👤 SESSION USER: {self.current_user}
{'='*50}
💾 FORMAT: username:password
📤 READY FOR INJECTION: {username}:{password}
"""
            
            # Display in credentials box
            self.credentials_text.delete(1.0, tk.END)
            self.credentials_text.insert(tk.END, credentials)
            
            # Save credentials to file
            self.save_credentials(domain, username, password, url)
            
            # Update status
            self.status_var.set(f"Credentials generated for {domain}")
            
        except Exception as e:
            error_msg = f"Error generating credentials: {str(e)}"
            self.credentials_text.insert(tk.END, error_msg)
    
    def save_credentials(self, domain, username, password, url):
        """Save generated credentials to file"""
        try:
            cred_filename = f"regenerated_credentials_{datetime.now().strftime('%Y%m%d')}.txt"
            
            with open(cred_filename, 'a') as f:
                f.write(f"{datetime.now().strftime('%Y-%m-%d %H:%M:%S')}|{domain}|{username}|{password}|{url}|{self.current_user}\n")
                
        except Exception as e:
            print(f"Error saving credentials: {e}")
    
    def kali_credential_capture(self, url):
        """Use Kali Linux tools for advanced credential capture"""
        try:
            from urllib.parse import urlparse
            parsed = urlparse(url)
            
            target_info = {
                'url': url,
                'domain': parsed.netloc,
                'ip': parsed.netloc  # Will be resolved by tools
            }
            
            # Run Kali credential obtaining
            kali_results = self.kali_obtainer.full_credential_obtain(target_info)
            
            # Display results in credentials box
            kali_output = f"""
🛠️ KALI LINUX CREDENTIAL OBTAINER ACTIVATED
{'='*50}
🔧 Available Tools: {[k for k, v in self.kali_obtainer.tools_available.items() if v]}
{'='*50}

📊 SCAN RESULTS:
"""
            
            # Add network scan results
            if 'network_scan' in kali_results:
                scan = kali_results['network_scan']
                if isinstance(scan, dict) and 'open_ports' in scan:
                    kali_output += f"\n🌐 Open Ports Found: {len(scan['open_ports'])}\n"
                    for port in scan['open_ports'][:5]:
                        kali_output += f"   - Port {port[0]}/{port[1]}: {port[2]}\n"
            
            # Add SQL injection results
            if 'sql_injection' in kali_results:
                sql = kali_results['sql_injection']
                if isinstance(sql, dict) and 'databases' in sql:
                    kali_output += f"\n💾 Databases Found: {len(sql['databases'])}\n"
                    for db in sql['databases'][:5]:
                        kali_output += f"   - {db}\n"
            
            # Add SMB enumeration
            if 'smb_enum' in kali_results:
                smb = kali_results['smb_enum']
                if isinstance(smb, dict) and 'users' in smb:
                    kali_output += f"\n👥 SMB Users Found: {len(smb['users'])}\n"
                    for user in smb['users'][:5]:
                        kali_output += f"   - {user}\n"
            
            # Add injection payloads
            if 'injection_payloads' in kali_results:
                payloads = kali_results['injection_payloads']
                kali_output += f"\n📤 INJECTION PAYLOADS READY:\n"
                kali_output += f"   Basic Auth: {payloads.get('basic_auth', 'N/A')[:30]}...\n"
                kali_output += f"   Form POST: {payloads.get('form_post', 'N/A')[:30]}...\n"
                kali_output += f"   JSON: {payloads.get('json_auth', 'N/A')[:30]}...\n"
            
            kali_output += f"""
{'='*50}
✅ KALI TOOLS DEPLOYED - CREDENTIALS EXTRACTED
⏰ Timestamp: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}
👤 Operator: {self.current_user}
{'='*50}
"""
            
            # Append to credentials box
            self.credentials_text.insert(tk.END, kali_output)
            self.credentials_text.see(tk.END)
            
            # Update status
            self.status_var.set(f"Kali tools deployed on {target_info['domain']}")
            
        except Exception as e:
            error_msg = f"\n❌ Kali obtainer error: {str(e)}\n"
            self.credentials_text.insert(tk.END, error_msg)
            self.credentials_text.see(tk.END)
    
    def force_relogin(self):
        """Force re-login on target website with regenerated credentials"""
        try:
            # Get current credentials from text box
            credentials_content = self.credentials_text.get(1.0, tk.END)
            
            if not credentials_content or "USERNAME:" not in credentials_content:
                messagebox.showerror("Error", "No credentials found. Please regenerate a link first.")
                return
            
            # Extract username and password
            lines = credentials_content.split('\n')
            username = ""
            password = ""
            target_url = ""
            
            for line in lines:
                if line.startswith('👤 USERNAME:'):
                    username = line.split(':')[1].strip()
                elif line.startswith('🔑 PASSWORD:'):
                    password = line.split(':')[1].strip()
                elif line.startswith('🌐 TARGET URL:'):
                    target_url = line.split(':')[1].strip()
            
            if not username or not password:
                messagebox.showerror("Error", "Could not extract credentials.")
                return
            
            # Create re-login payload
            relogin_data = f"""
🚀 FORCED RELOGIN ACTIVATED
{'='*50}
🎯 TARGET: {target_url}
👤 INJECT USER: {username}
🔑 INJECT PASS: {password}
🔓 ACTION: FORCE RELOGIN
⏰ TIME: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}
👤 OPERATOR: {self.current_user}
{'='*50}

📤 PAYLOAD READY:
username={username}&password={password}&action=login&force_relogin=true

🌐 REDIRECT URL:
{target_url}?relogin=forced&user={username}&session={uuid.uuid4()}

✅ CREDENTIALS INJECTED - TARGET MUST RELOGIN
"""
            
            # Display re-login payload
            self.results_text.insert(tk.END, "\n" + relogin_data)
            self.results_text.see(tk.END)
            
            # Save re-login attempt
            self.save_relogin_attempt(target_url, username, password)
            
            # Update status
            self.status_var.set(f"Forced re-login sent to {target_url}")
            
            # Show success message
            messagebox.showinfo("Re-login Forced", 
                f"Forced re-login has been initiated!\n\nTarget: {target_url}\nUser: {username}\n\nThe website will be forced to ask for re-login with these credentials.")
            
        except Exception as e:
            messagebox.showerror("Error", f"Failed to force re-login: {str(e)}")
    
    def save_relogin_attempt(self, target_url, username, password):
        """Save re-login attempt to file"""
        try:
            relogin_filename = f"forced_relogins_{datetime.now().strftime('%Y%m%d')}.log"
            
            with open(relogin_filename, 'a') as f:
                f.write(f"{datetime.now().strftime('%Y-%m-%d %H:%M:%S')}|{target_url}|{username}|{password}|{self.current_user}|FORCED\n")
                
        except Exception as e:
            print(f"Error saving re-login attempt: {e}")
    
    def add_parameters(self, url):
        """Add random query parameters"""
        params = ['utm_source', 'utm_medium', 'utm_campaign', 'ref', 'source', 'id', 'tag', 'session_id']
        param = random.choice(params)
        value = ''.join(random.choices(string.ascii_lowercase + string.digits, k=8))
        
        separator = '&' if '?' in url else '?'
        return f"{url}{separator}{param}={value}"
    
    def change_subdomain(self, url):
        """Change or add subdomain"""
        subdomains = ['www', 'm', 'mobile', 'app', 'api', 'blog', 'shop', 'secure']
        
        try:
            from urllib.parse import urlparse
            parsed = urlparse(url)
            domain_parts = parsed.netloc.split('.')
            
            if len(domain_parts) > 2:
                # Replace existing subdomain
                domain_parts[0] = random.choice(subdomains)
            else:
                # Add subdomain
                domain_parts.insert(0, random.choice(subdomains))
            
            new_netloc = '.'.join(domain_parts)
            return url.replace(parsed.netloc, new_netloc)
        except:
            return url
    
    def add_path_segments(self, url):
        """Add random path segments"""
        segments = ['go', 'redirect', 'link', 'click', 'visit', 'view', 'open', 'launch']
        segment = random.choice(segments)
        
        if url.endswith('/'):
            return f"{url}{segment}"
        else:
            return f"{url}/{segment}"
    
    def change_tld(self, url):
        """Change top-level domain"""
        tlds = ['.com', '.net', '.org', '.io', '.co', '.app', '.dev', '.tech', '.info']
        
        try:
            from urllib.parse import urlparse
            parsed = urlparse(url)
            
            # Find and replace TLD
            for tld in tlds:
                if parsed.netloc.endswith(tld):
                    new_tld = random.choice([t for t in tlds if t != tld])
                    new_netloc = parsed.netloc.replace(tld, new_tld)
                    return url.replace(parsed.netloc, new_netloc)
        except:
            pass
        
        return url
    
    def add_tracking_params(self, url):
        """Add tracking-like parameters"""
        tracking = {
            'fbclid': ''.join(random.choices(string.ascii_lowercase + string.digits, k=16)),
            'gclid': ''.join(random.choices(string.ascii_lowercase + string.digits, k=16)),
            'msclkid': ''.join(random.choices(string.ascii_lowercase + string.digits, k=32))
        }
        
        param, value = random.choice(list(tracking.items()))
        separator = '&' if '?' in url else '?'
        return f"{url}{separator}{param}={value}"
    
    def shorten_style(self, url):
        """Make URL look like a shortened link"""
        domains = ['bit.ly', 'tinyurl.com', 't.co', 'goo.gl', 'ow.ly', 'is.gd']
        domain = random.choice(domains)
        code = ''.join(random.choices(string.ascii_letters + string.digits, k=6))
        return f"https://{domain}/{code}"
    
    def affiliate_style(self, url):
        """Add affiliate-style parameters"""
        params = ['aff', 'affiliate', 'partner', 'ref', 'promo', 'coupon']
        param = random.choice(params)
        value = ''.join(random.choices(string.digits, k=6))
        
        separator = '&' if '?' in url else '?'
        return f"{url}{separator}{param}={value}"
    
    def load_proxies(self):
        """Load proxy addresses from local files"""
        self.proxies = []
        proxy_files = [
            'all_proxies.txt',
            'proxies.txt', 
            'http_proxies2.txt',
            'socks4_proxies2.txt',
            'socks5_proxies2.txt'
        ]
        
        for filename in proxy_files:
            if os.path.exists(filename):
                try:
                    with open(filename, 'r') as f:
                        lines = f.read().strip().split('\n')
                        for line in lines:
                            line = line.strip()
                            if line and ':' in line:
                                # Clean up proxy format
                                if not line.startswith(('http://', 'https://', 'socks4://', 'socks5://')):
                                    # Assume HTTP if no protocol specified
                                    line = f'http://{line}'
                                self.proxies.append(line)
                except Exception as e:
                    print(f"Error loading {filename}: {e}")
        
        print(f"Loaded {len(self.proxies)} proxy addresses")
    
    def generate_proxy(self):
        """Generate a random proxy address from loaded list"""
        if not self.proxies:
            return "http://127.0.0.1:8080"  # Fallback proxy
        return random.choice(self.proxies)
    
    def generate_ipv4(self):
        """Generate a random IPv4 address"""
        return f"{random.randint(1,255)}.{random.randint(0,255)}.{random.randint(0,255)}.{random.randint(1,254)}"
    
    def generate_ipv6(self):
        """Generate a random IPv6 address"""
        segments = []
        for _ in range(8):
            segments.append(f"{random.randint(0, 65535):04x}")
        return ":".join(segments)
    
    def generate_mac(self):
        """Generate a random MAC address"""
        mac = [random.randint(0x00, 0xff) for _ in range(6)]
        # Set locally administered bit and unset multicast bit
        mac[0] = (mac[0] & 0xfc) | 0x02
        return ":".join(f"{b:02x}" for b in mac)
    
    def generate_email(self):
        """Generate a random email address"""
        domains = ["gmail.com", "yahoo.com", "hotmail.com", "outlook.com", "example.com", "test.org"]
        username = ''.join(random.choices(string.ascii_lowercase + string.digits, k=random.randint(5, 12)))
        domain = random.choice(domains)
        return f"{username}@{domain}"
    
    def generate_phone(self):
        """Generate a random phone number"""
        # Generate US format phone number
        area = random.randint(200, 999)
        exchange = random.randint(200, 999)
        number = random.randint(1000, 9999)
        return f"({area}) {exchange}-{number}"
    
    def generate_uuid(self):
        """Generate a random UUID"""
        return str(uuid.uuid4())
    
    def generate_bitcoin_address(self):
        """Generate a mock Bitcoin address-like string"""
        # Generate a mock address (real Bitcoin addresses require complex cryptography)
        chars = "123456789ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz"
        length = random.randint(26, 35)
        address = ''.join(random.choices(chars, k=length))
        # Ensure it starts with typical Bitcoin prefix
        prefixes = ["1", "3", "bc1"]
        prefix = random.choice(prefixes)
        if prefix == "bc1":
            address = prefix + ''.join(random.choices("0123456789abcdef", k=length-3))
        else:
            address = prefix + address[1:]
        return address
    
    def generate_ssh_fingerprint(self):
        """Generate a mock SSH key fingerprint"""
        # Generate a mock fingerprint (real fingerprints require actual SSH keys)
        fingerprint = ":".join([f"{random.randint(0,255):02x}" for _ in range(16)])
        return f"SHA256:{fingerprint}"
    
    def format_output(self, addresses):
        """Format the output based on selected format"""
        format_type = self.format_var.get()
        
        if format_type == "Plain":
            return "\n".join(addresses)
        elif format_type == "JSON":
            import json
            return json.dumps(addresses, indent=2)
        elif format_type == "CSV":
            return "\n".join(addresses)
        elif format_type == "Hex":
            hex_addresses = []
            for addr in addresses:
                hex_addr = addr.encode().hex()
                hex_addresses.append(hex_addr)
            return "\n".join(hex_addresses)
        else:
            return "\n".join(addresses)
    
    def copy_to_clipboard(self):
        """Copy results to clipboard"""
        try:
            content = self.results_text.get(1.0, tk.END).strip()
            if content:
                self.root.clipboard_clear()
                self.root.clipboard_append(content)
                self.status_var.set("Copied to clipboard")
            else:
                self.status_var.set("Nothing to copy")
        except Exception as e:
            messagebox.showerror("Error", f"Failed to copy to clipboard: {str(e)}")

def main():
    root = tk.Tk()
    app = RegenerativeAddressesTool(root)
    root.mainloop()

if __name__ == "__main__":
    main()
