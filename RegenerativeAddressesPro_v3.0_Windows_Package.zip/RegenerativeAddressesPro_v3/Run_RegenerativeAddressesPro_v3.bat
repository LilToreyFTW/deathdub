@echo off
cd /d "%~dp0"
echo Starting Regenerative Addresses Tool Pro v3.0...
echo.
echo ===========================================
echo   Regenerative Addresses Tool Pro v3.0
echo   Professional Security Protection Tool
echo ===========================================
echo.
echo Features:
echo - Real Security Scanner and Protection
echo - System Hardening and Audit Tools
echo - Networking Security Education
echo - Professional Link Regeneration
echo - Enhanced Proxy Management
echo - PHP Web Interface Integration
echo.
python regenerative-addresses-pro.py
if errorlevel 1 (
    echo.
    echo Error running v3.0, trying original version...
    python regenerative-addresses.py
)
pause
