@echo off
cd /d "%~dp0"
echo Starting PHP Web Interface v3.0...
echo.
echo ===========================================
echo   Regenerative Addresses Tool Pro v3.0
echo   PHP Web Interface with Security Features
echo ===========================================
echo.
echo Features:
echo - Professional Security Dashboard
echo - Real-time Vulnerability Scanning
echo - System Hardening Interface
echo - Networking Education Portal
echo - Security Reporting System
echo.
echo Starting local PHP server...
echo Access: http://localhost:8000
echo Press Ctrl+C to stop server
echo.
cd src
python -m http.server 8000
pause
